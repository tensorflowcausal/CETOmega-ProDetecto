# CETOmega_ChecksPack

Run `python run_checks.py --all` inside this folder.
