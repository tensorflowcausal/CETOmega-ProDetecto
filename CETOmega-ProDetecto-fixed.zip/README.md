# CETOmega-ProDetecto (fixed bundle)

Open `CETOmega_ChecksPack/` and run the checks.
