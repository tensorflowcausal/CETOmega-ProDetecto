#!/bin/bash
echo 'Running FRG + Ringdown + Quantum...'
