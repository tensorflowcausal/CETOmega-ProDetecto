# CETOmega Complete Bundle
This archive contains:
- `CETOmega_FullRepo_v3/` (CI-ready repo with FRG, Ringdown, Quantum + run_validation.py)
- `CETOmega_v19.5_Full/` (CoreModels + ValidationPkg + DarkSectorBench, executable scaffolds)

Upload either folder to your GitHub repository.
