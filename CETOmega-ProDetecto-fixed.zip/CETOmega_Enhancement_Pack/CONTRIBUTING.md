
# Contributing to CETOmega
1. Fork the repo and create a feature branch.
2. Run `pytest` and `python demo_empirical_theory_of_everything.py` before submitting.
3. Open a Pull Request with a clear description and references.
