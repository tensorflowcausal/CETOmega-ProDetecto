# Kerr ringdown (scaffold)
def qnm_shift(a_star, poles):
    # placeholder mapping spin -> freq shift magnitude
    base = 1e-4
    return base*(1 + 2*(a_star-0.7))
