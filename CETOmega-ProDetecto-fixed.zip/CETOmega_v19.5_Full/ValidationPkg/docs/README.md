# Validation Package (CETOmega v19.5)
Run `python ../tests/run_all.py` or use individual tests under `tests/`.
