# CETOmega v19.5 Full
Executable pack for the Causal-Informational Theory (CETΩ⁺ v19.5).

## How to run
```
pip install -r ValidationPkg/docs/requirements.txt
python ValidationPkg/tests/run_all.py
```
Or open notebooks in `CoreModels/**` from Google Colab.
