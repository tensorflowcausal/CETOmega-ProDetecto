# CETOmega Full Repo v2

Empirical verification package for CETΩ framework.
