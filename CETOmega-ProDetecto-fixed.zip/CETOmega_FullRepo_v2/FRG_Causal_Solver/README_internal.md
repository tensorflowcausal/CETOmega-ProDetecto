# FRG_Causal_Solver

This module is part of the CETOmega-ProDetecto empirical validation framework.
