def qnm_shift(a_star):
    return 1e-4*(1+2*(a_star-0.7))
