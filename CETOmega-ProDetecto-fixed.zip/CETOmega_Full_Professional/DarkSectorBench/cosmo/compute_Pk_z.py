# compute P(k,z) — placeholder
