def test_cosmo_placeholder():
    assert True
