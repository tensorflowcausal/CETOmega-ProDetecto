def test_ringdown_bounds():
    assert 1e-6 < 1e-4 < 1e-3
