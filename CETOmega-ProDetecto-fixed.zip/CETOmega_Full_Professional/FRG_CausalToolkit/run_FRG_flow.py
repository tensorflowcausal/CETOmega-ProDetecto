
print("FRG flow scaffold — integrate causal kernel parameters and export evolution curves")
